from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings
from django.contrib.auth import views as auth_view
from .forms import loginForm, myPasswordResetForm, MyPasswordChangeForm,mySetPasswordForm
urlpatterns=[
    path('',views.home,name='home'),
    path('autocomplete/',views.autocomplete,name='autocomplete'),
    path('category/<slug:val>',views.categoryView.as_view(),name='category'),
    path('category-title/<val>',views.titleView.as_view(),name='category_title'),
    path('product-details/<int:id>',views.productDetails.as_view(),name='product_details'),
    path('profile/',views.profileView.as_view(),name='profile'),
    path('user_profile/',views.Profile.as_view(),name='user_profile'),
    path('user_update_profile/',views.userUpdateView.as_view(),name='user_update_profile'),

    path('address/',views.address,name='address'),
    path('update/<int:pk>',views.updateView.as_view(),name='update'),
    path('add_to_cart/',views.add_to_cart,name='add_to_cart'),
    path('cart/',views.show_cart,name='show_cart'),
    path('update_cart_address/<int:pk>',views.update_cart_address.as_view(),name='update_cart_address'),
    path('checkout/',views.checkout.as_view(),name='checkout'),
    path('paymentdone/',views.paymentdoneView,name='paymentdone'),
    path('orders/',views.orders,name='orders'),
    path('sort/<slug:val>',views.sort_by,name='sort'),

    path('search/',views.search,name='search'),
    path('wishlist/',views.wishlist,name='wishlist'),

    path('plus-cart/',views.plus_cart),
    path('minus-cart/',views.minus_cart),
    path('remove-cart/',views.remove_cart),

    path('wishlist-count/',views.wishlist_count),
    path('remove-wishlist/',views.remove_wishlist),

    path('shipping-address',views.shippingAddress),

    # authenticaton urls
    path('registration/',views.custmerRegistrationView.as_view(),name='registration'),
    path('new_user_profile/',views.custmerRegistrationView.as_view(),name='new_user_profile'),
    path('new_user_profile_create/',views.user_create_profile.as_view(),name='new_user_profile_create'),




    path('login/',auth_view.LoginView.as_view(template_name='krishna_app/login.html',authentication_form=loginForm),name='login'),
    path('logout/',views.custom_logout,name='logout'),


    path('password_change/',auth_view.PasswordChangeView.as_view(template_name='krishna_app/password_change.html',form_class=MyPasswordChangeForm,success_url='/password_change_done'),name='password_change'),
    path('password_change_done/',auth_view.PasswordChangeDoneView.as_view(template_name='krishna_app/password_change_done.html'),name='password_change_done'),
    
    path('password-reset/',auth_view.PasswordResetView.as_view(template_name='krishna_app/password_reset.html',form_class=myPasswordResetForm),name='password_reset'),
    path('password_reset_done/',auth_view.PasswordResetDoneView.as_view(template_name='krishna_app/password_reset_done.html'),name='password_reset_done'),
    path('password_reset_confirm/<uidb64>/<token>/',auth_view.PasswordResetConfirmView.as_view(template_name='krishna_app/password_reset_confirm.html',form_class=mySetPasswordForm),name='password_reset_confirm'),
    path('password_reset_complete/',auth_view.PasswordResetCompleteView.as_view(template_name='krishna_app/password_reset_complete.html'),name='password_reset_complete'),


]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
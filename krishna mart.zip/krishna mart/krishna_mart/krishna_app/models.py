from django.db import models
from django.contrib.auth.models import User
# Create your models here.

TITLE_CHOICES=[
    ('Farmer','Farmer'),
    ('Chariot','Chariot'),
    ('Developer','Developer'),
    ('Doctor','Doctor'),
    ('Politician','Politician'),
    ('House-wife','House-wife')
    ]


class Profile(models.Model):
    user=models.OneToOneField(User,null=True,on_delete=models.CASCADE)
    title=models.CharField(max_length=15,choices=TITLE_CHOICES,default='farmer')
    profile_pic=models.ImageField(upload_to='product',null=True,blank=True)
    contact_num=models.CharField(max_length=15,null=True)
    gender=models.CharField(max_length=6,choices=[('male','male'),('female','female')],default='male')
    dob=models.DateField(null=True)
    bio=models.TextField(null=True,blank=True)
    address=models.TextField(null=True,blank=True)
    def __str__(self):
        return self.user.username


CATEGORY_CHOICES=(
    ('vegitables','vegitables'),
    ('fruits','fruits'),
    ('dairy','dairy'),
    ('chacolates','chacolates'),
    ('cosmotics','cosmotics'),
)

class Product(models.Model):
    title=models.CharField(max_length=30)
    price=models.IntegerField()
    category=models.CharField(choices=CATEGORY_CHOICES, max_length=10)
    info=models.TextField(default='')
    product_image=models.ImageField(upload_to='product')
    item_stock=models.IntegerField(default=10)
    def __str__(self):
        return self.title
    

STATE_CHOICE=(
    ('andhra pradesh','andhra pradesh'),
    ('telangana','telangana'),
    ('karnataka','karnatake'),
    ('tamilnadu','tamilnadu'),
    ('kerala','kerala'),
)
class Customer(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    name=models.CharField(max_length=30)
    locality=models.CharField(max_length=30)
    city=models.CharField(max_length=30)
    mobile=models.IntegerField(default=0)
    pincode=models.IntegerField()
    state=models.CharField(choices=STATE_CHOICE,max_length=20)
    status=models.BooleanField(default=False)
    def __str__(self):
        return self.name
    
class Cart(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity=models.PositiveIntegerField(default=1)
    
    def price(self):
        return self.product.price
    @property
    def total_product_price(self):
        return self.quantity*self.product.price
    
STATUS_CHOICE=(
    ('accepted','accepted'),
    ('pending','pending'),
    ('cancel','cancel'),
    ('delivered','delivered'),
    ('packed','packed'),
    ('on-the-way','on-the-way'),
)

class Payment(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    amount=models.FloatField()
    razorpay_order_id=models.CharField(max_length=100,blank=True,null=True)
    razorpay_payment_id=models.CharField(max_length=100,null=True,blank=True)
    razorpay_payment_status=models.CharField(max_length=100,blank=True,null=True)
    cust_add_id=models.CharField(max_length=100,blank=True,null=True)
    paid=models.BooleanField(default=False)

class orderPlaced(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    customer=models.ForeignKey(Customer,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity=models.PositiveIntegerField(default=1)
    ordered_date=models.DateTimeField(auto_now_add=True)
    status=models.CharField(max_length=50,choices=STATUS_CHOICE,default='pending')
    payment=models.ForeignKey(Payment,on_delete=models.CASCADE,default="")
    @property
    def total_cost(self):
        return self.quantity*self.product.price

class Wishlist(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)



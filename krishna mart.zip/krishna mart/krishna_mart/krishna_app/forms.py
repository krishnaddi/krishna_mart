from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, UsernameField,PasswordChangeForm, PasswordResetForm,SetPasswordForm
from django.contrib.auth.models import User
from .models import Customer,Profile
from django.db import models
from django.forms import fields

class customerRegistrationForm(UserCreationForm):
    username=forms.CharField(widget=forms.TextInput(attrs={'autofocus':'true','class':'form-control'}))
    email=forms.EmailField(widget=forms.EmailInput(attrs={'class':'form-control'}))
    password1=forms.CharField(label='password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
    password2=forms.CharField(label='confirm password',widget=forms.PasswordInput(attrs={'class':'form-control'}))

    class Meta:
        model=User
        fields=['username','email','password1','password2']

class loginForm(AuthenticationForm):
    username=UsernameField(widget=forms.TextInput(attrs={'autofocus':'true','class':'form-control'}))
    password=forms.CharField(label='password',widget=forms.PasswordInput(attrs={'class':'form-control'}))


class userProfileForm(forms.ModelForm):
    class Meta:
        model=Profile
        fields=['title','profile_pic','contact_num','gender','dob','bio','address']
        widgets={
            
            'title':forms.Select(attrs={'class':'form-control'}),
            'profile_pic':forms.FileInput(attrs={'class':'form-control btn-pic'}),
            'contact_num':forms.TextInput(attrs={'class':'form-control'}),
            'gender':forms.Select(attrs={'class':'form-control'}),
            'dob':forms.NumberInput(attrs={'class':'form-control','type':'date'}),
            'bio':forms.Textarea(attrs={'class':'form-control','rows':3}),
            'address':forms.TextInput(attrs={'class':'form-control'}),
        }


class customerAddressForm(forms.ModelForm):
    
    class Meta:
        model=Customer
        # img = forms.ImageField(widget=forms.FileInput(attrs={'class':'form-control'}))

        fields=['name','locality','city','mobile','pincode','state']
        widgets={
            'name':forms.TextInput(attrs={'class':'form-control','autofocus':'true','onfocus':'this.setSelectionRange(this.value.length,this.value.length)'}),
            'locality':forms.TextInput(attrs={'class':'form-control'}),
            'city':forms.TextInput(attrs={'class':'form-control'}),
            'mobile':forms.NumberInput(attrs={'class':'form-control'}),
            'pincode':forms.NumberInput(attrs={'class':'form-control'}),
            'state':forms.Select(attrs={'class':'form-control'}),
        }

class MyPasswordChangeForm(PasswordChangeForm):
    old_password=forms.CharField(label='old password',widget=forms.PasswordInput(attrs={'autofocus':'True','autocomplete':'current-password','class':'form-control'}))
    new_password1=forms.CharField(label='new password',widget=forms.PasswordInput(attrs={'autocomplete':'current-password','class':'form-control'}))
    new_password2=forms.CharField(label='confirm password',widget=forms.PasswordInput(attrs={'autocomplete':'current-password','class':'form-control'}))

class myPasswordResetForm(PasswordResetForm):
    email=forms.EmailField(widget=forms.EmailInput(attrs={'class':'form-control'}))

class mySetPasswordForm(SetPasswordForm):
    new_password1=forms.CharField(label='new password',widget=forms.PasswordInput(attrs={'autocomplete':'current-password','class':'form-control'}))
    new_password2=forms.CharField(label='confirm new password',widget=forms.PasswordInput(attrs={'autocomplete':'current-password','class':'form-control'}))
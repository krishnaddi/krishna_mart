from django.contrib import admin
from .models import Payment, Product, Customer, Cart, orderPlaced,Wishlist,Profile
# Register your models here.


admin.site.register(Profile)

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display=['id','title','price','category','product_image','item_stock']


@admin.register(Customer)
class customerAdmin(admin.ModelAdmin):
    list_display=['id','name','locality','city','mobile','pincode','state','status']

@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display=['id','user','product','quantity','price','total_product_price']
    
@admin.register(Payment)
class paymentAdmin(admin.ModelAdmin):
    list_display=['id','user','amount','paid','razorpay_order_id','razorpay_payment_id','razorpay_payment_status','cust_add_id']

@admin.register(orderPlaced)
class orderPlacedAdmin(admin.ModelAdmin):
    list_display=['id','user','customer','product','quantity','status','payment','ordered_date']

@admin.register(Wishlist)
class wishlistAdmin(admin.ModelAdmin):
    list_display=['id','user','product']
from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views import View
import razorpay
from .models import Payment, Product,Customer,Cart,orderPlaced,Wishlist,Profile as p
from .forms import customerRegistrationForm, customerAddressForm, userProfileForm
from django.contrib import messages
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.contrib.auth.models import User
import os

class Profile(View):
    def get(self,request):
        user=User.objects.get(id=request.user.id)
        return render(request,'krishna_app/user_profile.html',locals())


def home(request):
    
    if request.user.is_authenticated:
            totalItems=len(Cart.objects.filter(user=request.user))
            wishlist_count=len(Wishlist.objects.filter(user=request.user))
    products=Product.objects.all() 
    return render(request,'krishna_app/home.html',locals())

class custmerRegistrationView(View):
    def get(self,request):
        form=customerRegistrationForm()
        return render(request,'krishna_app/registration.html',locals())
    def post(self,request):
        form=customerRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,'registered successfully...')
        else:
            messages.warning(request,'registration failed...')
        return redirect('login')

def sort_by(request,val):
        products=Product.objects.all().order_by(val)
        return render(request,'krishna_app/sort.html',locals())

        

class categoryView(View):
    def get(self,request,val):
        product=Product.objects.filter(category=val)
        title=Product.objects.filter(category=val).values('title')
        return render(request,'krishna_app/category.html',locals())
    
class titleView(View):
    def get(self,request,val):
        product=Product.objects.filter(title=val)
        title=Product.objects.filter(category=product[0].category).values('title')
        return render(request,'krishna_app/category.html',locals())

class productDetails(View):
    def get(self,request,id):
        product=Product.objects.get(pk=id)
        wishlist_count=len(Wishlist.objects.filter(user=request.user))
        wishlist=Wishlist.objects.filter(Q(user=request.user)&Q(product=product))
        return render(request,'krishna_app/product_details.html',locals())



class profileView(View):
    def get(self,request):
        form=customerAddressForm()
        return render(request,'krishna_app/update.html',locals())
    def post(self,request):
        form=customerAddressForm(request.POST)
        if form.is_valid():
            user=request.user
            name=form.cleaned_data['name']
            locality=form.cleaned_data['locality']
            city=form.cleaned_data['city']
            mobile=form.cleaned_data['mobile']
            state=form.cleaned_data['state']
            pincode=form.cleaned_data['pincode']
            obj=Customer(user=user,name=name,mobile=mobile,locality=locality,city=city,state=state,pincode=pincode)
            obj.save()
            messages.success(request,'address saved successfully')
        else:
            messages.warning(request,'address not saved')
        return redirect('address')
        
def new_address(request):
    return render(request,'krishna_app/new_address.html')


def address(request):
    add=Customer.objects.filter(user=request.user)
    return render(request,'krishna_app/address.html',locals())
        
# class addAddress(View):
#     def get(self,request):
#         form=customerAddressForm()
#         return render(request,'krishna_app/new_address.html',locals())
#     def post(self,request):
#         form=customerAddressForm(request.POST,request.FILES)
#         if form.is_valid():
#             profile=p.objects.get(user=request.user)
#             profile.title=form.cleaned_data['title']
#             profile.contact_num=form.cleaned_data['contact_num']
#             profile.gender=form.cleaned_data['gender']
#             profile.dob=form.cleaned_data['dob']
#             profile.bio=form.cleaned_data['bio']
#             profile.address=form.cleaned_data['address']
#             if not form.cleaned_data['profile_pic']:
#                 profile.save()
#                 return redirect('profile')
#             profile.profile_pic=form.cleaned_data['profile_pic']
#             profile.save()
#             messages.success(request,'updated')
#         else:
#             messages.warning(request,'not updated')
#             return redirect('user_update_profile')
#         return redirect('profile')



class user_create_profile(View):
    def get(self,request):
        form=userProfileForm()
        return render(request,'krishna_app/new_user_profile.html',locals())
    def post(self,request):
        form=userProfileForm(request.POST,request.FILES)
        if form.is_valid():
            
            p.user=form.cleaned_data['user']
            p.title=form.cleaned_data['title']
            p.contact_num=form.cleaned_data['contact_num']
            p.gender=form.cleaned_data['gender']
            p.dob=form.cleaned_data['dob']
            p.bio=form.cleaned_data['bio']
            p.address=form.cleaned_data['address']
            p.profile_pic=form.cleaned_data['profile_pic']
            p.save(User)
        return redirect('login')


class userUpdateView(View):
    def get(self,request):
        user=request.user
        profile=p.objects.filter(user=user)
        form=userProfileForm(instance=user.profile)
        return render(request,'krishna_app/user_update_profile.html',locals())
    def post(self,request):
        form=userProfileForm(request.POST,request.FILES)
        if form.is_valid():
            profile=p.objects.get(user=request.user)
            if len(request.FILES)!=0:
                if len(profile.profile_pic)>0:
                    os.remove(profile.profile_pic.path)
            profile.title=form.cleaned_data['title']
            profile.contact_num=form.cleaned_data['contact_num']
            profile.gender=form.cleaned_data['gender']
            profile.dob=form.cleaned_data['dob']
            profile.bio=form.cleaned_data['bio']
            profile.address=form.cleaned_data['address']
            if not form.cleaned_data['profile_pic']:
                profile.save()
                return redirect('user_profile')
            profile.profile_pic=form.cleaned_data['profile_pic']
            profile.save()
            messages.success(request,'updated')
        else:
            messages.warning(request,'not updated')
            return redirect('user_update_profile')
        return redirect('user_profile')

    

class updateView(View):
    def get(self,request,pk):
        add=Customer.objects.get(pk=pk)
        form=customerAddressForm(instance=add)
        return render(request,'krishna_app/update.html',locals())
    def post(self,request,pk):
        form=customerAddressForm(request.POST)
        if form.is_valid():
            add=Customer.objects.get(pk=pk)
            add.name=form.cleaned_data['name']
            add.locality=form.cleaned_data['locality']
            add.city=form.cleaned_data['city']
            add.mobile=form.cleaned_data['mobile']
            add.pincode=form.cleaned_data['pincode']
            add.state=form.cleaned_data['state']
            add.save()
        return redirect('address')
    
class update_cart_address(View):
    def get(self,request,pk):
        add=Customer.objects.get(pk=pk)
        form=customerAddressForm(instance=add)
        return render(request,'krishna_app/update_cart_address.html',locals())
    
    def post(self,request,pk):
        form=customerAddressForm(request.POST)
        if form.is_valid():
            add=Customer.objects.get(pk=pk)
            add.name=form.cleaned_data['name']
            add.locality=form.cleaned_data['locality']
            add.city=form.cleaned_data['city']
            add.mobile=form.cleaned_data['mobile']
            add.pincode=form.cleaned_data['pincode']
            add.state=form.cleaned_data['state']
            add.save()
        return redirect('show_cart')
        
@login_required
def custom_logout(request):
    logout(request)
    return redirect('home')

def add_to_cart(request):
    user=request.user
    product_id=request.GET.get('prod_id')
    product=Product.objects.get(id=product_id)
    cart=Cart.objects.filter(product=product_id)
    if not cart:
        Cart(user=user,product=product).save()
        product.item_stock-=1
        product.save()
    else:
        cart=Cart.objects.filter(Q(user=user)&Q(product=product_id))
        if not cart:
            Cart(user=user,product=product).save()
            product.item_stock-=1
            product.save()
        else:
            cart=Cart.objects.get(Q(product=product_id)&Q(user=user))
            cart.quantity+=1
            product.item_stock-=1
            product.save()
            cart.save()
    print(product.item_stock)
    return redirect('/cart')
    

def show_cart(request):
    products=Product.objects.all()
    totalItems=len(Cart.objects.filter(user=request.user))
    wishlist_count=len(Wishlist.objects.filter(user=request.user))
    
    add=Customer.objects.filter(user=request.user)
    user=request.user
    cart=Cart.objects.filter(user=user)
    amount=0
    for p in cart:
        value=p.quantity*p.product.price
        amount=amount+value
    total_amount=amount+10
    return render(request,'krishna_app/add_to_cart.html',locals())

class checkout(View):
    def get(self,request):
        user=request.user
        a=Customer.objects.get(Q(user=user)&Q(status=True))
        # add=Customer.objects.filter(user=request.user)
        items=Cart.objects.filter(user=user)
        amount=0
        for p in items:
            value=p.product.price*p.quantity
            amount+=value
        total_amount=amount+10
        razoramount=int(total_amount*100)
        client=razorpay.Client(auth=(settings.RAZOR_KEY_ID,settings.RAZOR_KEY_SECRET))
        data={"amount":razoramount,"currency":"INR","receipt":"order_rcptid_12"}
        payment_response=client.order.create(data=data)
        print(payment_response)
        order_id=payment_response['id']
        order_status=payment_response['status']
        if order_status=='created':
            payment=Payment(
                user=user,
                amount=total_amount,
                razorpay_order_id=order_id,
                razorpay_payment_status=order_status,
                cust_add_id=a.id,
            )
            payment.save()
        return render(request,'krishna_app/checkout.html',locals())

def paymentdoneView(request):
    order_id=request.GET.get('order_id')
    payment_id=request.GET.get('payment_id')
    a=Customer.objects.get(Q(user=request.user)&Q(status=True))
    user=request.user
    customer=Customer.objects.get(id=a.id)
    payment=Payment.objects.get(razorpay_order_id=order_id)
    payment.paid=True
    payment.razorpay_payment_id=payment_id
    payment.save()
    cart=Cart.objects.filter(user=request.user)
    for c in cart:
        orderPlaced(user=request.user,customer=customer,product=c.product,quantity=c.quantity, payment=payment).save()
        c.delete()
    return redirect('orders')


def plus_cart(request):
    if request.method=="GET":
        product_id=request.GET['prod_id']
        product=Product.objects.get(id=product_id)
        if(product.item_stock>0):
            cart=Cart.objects.get(Q(product=product_id)&Q(user=request.user))
            cart.quantity+=1
            product.item_stock-=1
            product.save()
            cart.save()
            user=request.user
            c=Cart.objects.filter(user=user)
            amount=0
            for item in c:
                value=item.quantity*item.product.price
                amount+=value
            total_amount=amount+10
            data={
                'amount':amount,
                'total_amount':total_amount,
                'quantity':cart.quantity,
                'total_product_price':cart.total_product_price,
                'messages':'',
            }
        return JsonResponse(data)
            
            

def minus_cart(request):
    if request.method=="GET":
        product_id=request.GET['product_id']
        product=Product.objects.get(id=product_id)
        cart=Cart.objects.get(Q(product=product_id)&Q(user=request.user))
        cart.quantity-=1
        cart.save()
        product.item_stock+=1
        product.save()
        if cart.quantity<1:
            cart.delete()
        user=request.user
        c=Cart.objects.filter(user=user)
        amount=0
        for item in c:
            value=item.quantity*item.product.price
            amount+=value
        total_amount=amount+10
        cart_lenght=len(c)
        totalItems=len(Cart.objects.filter(user=request.user))


        data={
            'quantity':cart.quantity,
            'amount':amount,
            'total_amount':total_amount,
            'total_product_price':cart.total_product_price,
            'cart_length':cart_lenght,
            'totalItems':totalItems,


        }
        return JsonResponse(data)

def remove_cart(request):
    if request.method=="GET":
        product_id=request.GET['prod_id']
        product=Product.objects.get(id=product_id)
        c=Cart.objects.get(Q(product=product_id)&Q(user=request.user))
        cart_item=c.quantity
        product.item_stock+=cart_item
        product.save()
        totalItems=len(Cart.objects.filter(user=request.user))
        c.delete()
        user=request.user
        cart=Cart.objects.filter(user=user)
        amount=0
        for item in cart:
            value=item.quantity*item.product.price
            amount+=value
        total_amount=amount+10
        cart_lenght=len(cart)
        data={
            'amount':amount,
            'total_amount':total_amount,
            'cart_length':cart_lenght,
            'totalItems':totalItems-1,
        }
        return JsonResponse(data)

def wishlist_count(request):
    if request.method=="GET":
        prod_id=request.GET['prod_id']
        product=Product.objects.get(id=prod_id)
        user=request.user
        wishlist=Wishlist.objects.filter(user=user).values_list('product')
        l=[]
        for w in wishlist:
            l.append(w[0])
        if int(prod_id) in l:
            Wishlist.objects.filter(user=user,product=product).delete()
        else:
            Wishlist(user=user,product=product).save()
        totalWishlistItems=len(Wishlist.objects.filter(user=request.user))
        data={
            'totalWishlistItems':totalWishlistItems,
        }
        return JsonResponse(data)

def shippingAddress(request):
    print('before enter get')
    if request.method=="POST":
        cust_id=request.POST['cust_id']
        print(cust_id)
        customers=Customer.objects.filter(user=request.user)
        for c in customers:
            c.status=False
            c.save()
        cust=Customer.objects.get(id=cust_id)
        cust.status=True
        cust.save()
        data={
            
        }
        return JsonResponse(data)
    
    
def remove_wishlist(request):
    if request.method=="GET":
        prod_id=request.GET['prod_id']
        product=Product.objects.get(id=prod_id)
        Wishlist.objects.filter(user=request.user,product=product).delete()
        totalWishlistItems=len(Wishlist.objects.filter(user=request.user))
        data={
            'totalWishlistItems':totalWishlistItems,
            'message':'removed item from wishlist',
        }
        return JsonResponse(data)

def wishlist(request):
    if request.user.is_authenticated:
        wishlist=Wishlist.objects.filter(user=request.user)
        wishlist_count=len(Wishlist.objects.filter(user=request.user))
        totalItems=len(Cart.objects.filter(user=request.user))
        return render(request,'krishna_app/wishlist.html',locals())

def search(request):
    query=request.GET['search']
    products=Product.objects.filter(Q(title__icontains=query)|Q(category__icontains=query))
    return render(request,'krishna_app/search.html',locals())

def autocomplete(request):
    if 'term' in request.GET:
        qs=Product.objects.filter(title__icontains=request.GET.get('term'))
        titles=list()
        for product in qs:
            titles.append(product.title)
        return JsonResponse(titles,safe=False)
    return render(request,'krishna_app/home.html')

def orders(request):

    orders=orderPlaced.objects.filter(user=request.user).order_by('-ordered_date')
    return render(request,'krishna_app/orders.html',locals())

